# Worldbuilding — TerraMythica

The full canon of the world, split by subject so any one system can be looked up
without wading through the others.

| Folder | Covers |
|---|---|
| `magic-system/` | The Emblems, the power system & underlying "physics," Fractal Cognition |
| `characters/` | Character design notes, personal-arc backstories, individual profiles |
| `factions-organizations/` | Order of the Emblematic, faction politics, hidden/secret societies, regional politics |
| `geography-cartography/` | Cartography systems, layered regional geography |
| `culture-society/` | Social strata & castes, festivals/rites/taboos, calendars & timekeeping |
| `religion-cosmology/` | Deities, creation myths, cosmology |
| `creatures-bestiary/` | Spiritwild inhabitants, magic-evolved fauna, the Nightmares |
| `language/` | Tongues & scripts, dialect tables, the Language of Emotion |
| `history-timeline/` | World-shaping historical events |
| `economy-technology/` | Economic systems (e.g. Solireth's fiscal budget) |
| `artifacts-weapons/` | Artifact/weapon/Emblem concept sheets |
| `transportation/` | Flying caravans, ley-train lines, memory ferries |

See `general-overview.md` for the cross-cutting worldbuilding approach and the lore
classification/taxonomy system that ties all of the above together.
