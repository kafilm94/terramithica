# Language

Files in this folder:

- `language-of-emotion.md`
- `languages-dialects-table.md`
- `tongues-and-scripts.md`
