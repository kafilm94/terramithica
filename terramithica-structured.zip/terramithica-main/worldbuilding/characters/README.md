# Characters

Files in this folder:

- `character-design-notes.md`
- `council-member-profile.md`
- `key-figures-intro.md`
- `personal-arcs.md`
