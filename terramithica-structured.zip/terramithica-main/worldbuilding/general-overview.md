---
title: "General Worldbuilding Approach & Lore Taxonomy"
tags: [worldbuilding, overview, taxonomy]
source_logs: [Log(4).md, Log(51).md, Log(59).md, Log(33).md]
filed_on: "2026-07-28"
note: "Filed verbatim from original conversation-logs archive; originals untouched."
---

# General Worldbuilding Approach & Lore Taxonomy

## Source: Log(4).md


This approach to worldbuilding is well-structured, and it balances creativity with consistency. Let's break down each part and apply it specifically to Terra-Mythica and Shadows of the Veil: Awakening of the Emblematic, focusing on key elements that fit the world and themes you've already established.

1. Outline and Structure
A. Worldbuilding Bible
We'll develop a living document for Terra-Mythica, with sections dedicated to:

History: The rise of the Emblems, the Phoenix, societal corruption, and key events leading to the story's timeline.

Geography: The unique terrains, cities, and natural features where the story takes place. For example, the Capitol City of Ethelyn, with its high-tech, decaying structures contrasting with the ancient forests that house rebellious factions.

Culture: The distinct cultures of Emblematic members, their adversaries, and common folk. What values are held by each group? How does the Order of the Emblematic blend history, tradition, and resistance?

Technology & Magic: Since your world blends technology and magic, we'll explore how these systems coexist. How does the power of the Emblems interact with or disrupt advanced technology?

B. Worldbuilding Template
Using a worldbuilding template will allow us to dive deeper into each section, ensuring that everything from terrain to daily life in Terra-Mythica has depth. We'll start with geography, since that will tie directly into designing your cities and landscapes.

C. Start with the Basics
For Terra-Mythica, we can prioritize its geography and cultural aspects first, so we’ll start by mapping out key locations like:

Phoenix’s Peak: The origin of the Phoenix and a sacred place for Damion.

Nightmare Wastelands: A dangerous, corrupted area where Nightmares emerge, where one of Damion’s major battles takes place.

Order of the Emblematic Headquarters: A hidden, ancient structure that serves as a safe haven for resistance leaders.

2. Research and Inspiration
A. Gather References
Reference key visual and thematic inspirations from other media like Final Fantasy, The Witcher, and Attack on Titan for dark, gritty world settings, and balance it with works that mix tech and magic like The Stormlight Archive.

B. Online Resources
Explore worldbuilding forums, such as World Anvil or Reddit’s r/worldbuilding, for feedback on specific aspects like city structure, societal conflicts, and more.

C. Brainstorming Techniques
Try mind mapping the connections between the Emblems and how their powers influence Terra-Mythica’s environment and factions. Freewriting can help with visualizing key areas like the Capitol City of Ethelyn.

3. Consistency and Coherence
A. Establish Rules
Terra-Mythica needs rules governing its magic and technology. Example:

Emblem Powers: Each Emblem draws power from an ancient source, but the user must adhere to certain rituals to harness it.

Technology vs. Magic: Emblems are feared in high-tech areas because their magic disrupts or weakens advanced systems.

B. Avoid Plot Holes
We need to track how geography affects politics and warfare. For example, if an Emblem disrupts technology, how does that impact a tech-dependent city like Ethelyn during battle?

C. Seek Feedback
Presenting your ideas to a focused community or beta readers can highlight issues and provide inspiration. We can look at specific subreddits, Discord servers, or other platforms to gather early feedback on key elements.

4. Prioritize and Focus
A. Identify Key Elements
Focus on the regions that will appear early in the story: Ethelyn, Phoenix’s Peak, and Nightmare Wastelands. These areas will ground your readers and set the stage for the conflict.

B. Avoid Overcomplicating
Keep in mind the main conflicts: rebellion, identity, and the clash between ancient magic and new technology. The world doesn’t need excessive subplots; prioritize the narrative arcs that push these themes forward.

By using this process, we’ll create a clear and richly detailed world that remains coherent and immersive. For next steps, would you like to focus on geography first, perhaps mapping out the Capitol City of Ethelyn or Phoenix’s Peak?


What about luminara in the surrounding area?

Memory updated
Let's dive into Luminara and its surrounding area, applying the worldbuilding techniques discussed.

Luminara - Overview
1. Geographical Features
Luminara is a key region, potentially known for its natural beauty or strategic importance. The name suggests something related to light, which could be literal or symbolic.

Terrain: Rolling hills and forests around Luminara that seem to glow in moonlight due to the bioluminescent flora. This gives the region an ethereal feel, creating a stark contrast with darker or industrialized areas like Ethelyn.

Climate: Mild and temperate, with lush greenery during most of the year. The land thrives thanks to ancient underground springs said to be blessed by the Emblems.

2. City Design
Central City of Luminara: Built around a grand central monument that channels energy from the land itself, this city has a reputation for being a place of healing and peace. While technologically advanced, the city has preserved its natural beauty through clean, integrated designs where technology and nature coexist seamlessly.

Architecture: Luminara’s structures have a biophilic design, with buildings made from naturally occurring materials and shaped to integrate into the surrounding hills. They could use an energy system powered by natural forces such as wind or solar power, enhanced by Emblem magic.

3. Cultural Importance
Cultural Hub: Luminara is known for its cultural heritage, with libraries, shrines, and meeting places where knowledge of both the old world (pre-tech) and modern advancements is shared freely. It could serve as a neutral ground where even factions at war come to seek respite.

Connection to the Emblems: Luminara has a unique spiritual connection to the Emblems, especially the Phoenix. Many pilgrims come here seeking enlightenment, making it a place where the Order of the Emblematic may have hidden influence, quietly guiding the city’s leadership.

4. Luminara’s Role in the Conflict
As the conflict between the Order of the Emblematic and the oppressive regime escalates, Luminara becomes a symbol of hope and resilience, but it may also become a target due to its peaceful stance and refusal to militarize.

Nightmare Presence: The surrounding forests have been slowly encroached upon by Nightmares, and there are rumors that the bioluminescent plants have begun to dim as the corruption spreads. Damion’s role may involve defending Luminara from these growing threats, as it holds strategic and symbolic importance for the resistance.

Surrounding Areas
Ethelyn Outskirts

Just beyond the glistening hills of Luminara lies the sprawling urban decay of Ethelyn, a metropolis steeped in technology and secrecy. These outskirts form a boundary where the natural world of Luminara meets the harsh industrial environment of Ethelyn.

Polluted River: A river flowing from Ethelyn into the surrounding wilderness near Luminara is heavily polluted, symbolizing the city's corruption. The once-clear waters have been tainted, and the people of Luminara have been battling to purify it using both technology and magic.

Nightmare Wastelands

Encroaching Darkness: To the east of Luminara, beyond the forests, the land gives way to the Nightmare Wastelands. These corrupted lands are plagued by horrific creatures and blighted vegetation. Over time, small incursions of these Nightmares into Luminara's forest indicate a growing threat.

Dangerous Pathways: Between Luminara and the wastelands, there are narrow, treacherous paths that are avoided by most travelers. Only the bravest, or most desperate, venture this way, often not returning.

Serene Valley

A protected valley to the north of Luminara, known for its deep canyons and crystalline waters. This peaceful place has long been a haven for spiritual reflection, home to an ancient shrine tied to the Phoenix. Damion may find guidance here as he grapples with the responsibilities of the Phoenix Emblem.

Luminara and Its Surrounding Area: Key Elements
Symbolism of Light and Dark:

Luminara represents balance and harmony, a beacon of light amidst the encroaching darkness of both technological exploitation (Ethelyn) and magical corruption (Nightmare Wastelands).

Cultural and Strategic Importance:

It serves as a neutral ground but also holds a hidden power—its natural magic and connection to the Emblems—that could be vital to tipping the balance in the ongoing conflict.

Integration of Technology and Magic:

Luminara’s balance between nature and technology contrasts with the polluted industrial zones of nearby Ethelyn, offering a glimpse of what Terra-Mythica might be if the Emblems’ wisdom were followed.

By focusing on Luminara as a key region, it can play a pivotal role in Shadows of the Veil as a place of sanctuary, learning, and eventual confrontation. Would you like to explore how Luminara might evolve in the story, or focus on designing specific locations within it?


Do you think it fits story that has been developed so far?

Yes, I think the design of Luminara fits well with the world and themes you've developed for Shadows of the Veil: Awakening of the Emblematic. Here's why:

1. Contrasting Themes of Light and Dark:
Luminara’s Symbolism aligns with the broader narrative of balancing internal and external conflict. Damion Knightly’s struggle with his identity as the bearer of the Mark of the Phoenix can be mirrored in Luminara’s precarious position between light (its natural beauty and peace) and the encroaching darkness of the Nightmare Wastelands and the corrupted technology of Ethelyn.

This mirrors the Order of the Emblematic as a group that challenges a corrupt system while battling internal fears, much like Luminara exists as a region resisting both external threats (Nightmares) and the technological exploitation from nearby cities.

2. A Place of Reflection and Growth:
Since Damion’s journey involves understanding his powers and responsibilities, Luminara’s reputation as a place of healing, reflection, and spiritual guidance offers him a sanctuary. The Phoenix’s Shrine in the nearby Serene Valley provides a meaningful location for his character development, aligning with the larger narrative of discovery and awakening that you’ve set up in Chapter 1.

3. Tech vs. Magic Conflict:
Terra-Mythica’s blend of technology and magic is a central element of your story. Luminara, with its balance of natural magic and integrated technology, contrasts with Ethelyn’s corrupt, tech-dominated society. This dynamic adds depth to the world and supports the overarching theme of rebellion against a system corrupted by fear and division.

4. Strategic Importance in the Conflict:
As Damion confronts the Nightmares in Chapter 5, Luminara’s role as a region under siege by both dark forces and potential political manipulation (due to its refusal to militarize) fits into the larger story. Luminara represents a bastion of hope and authenticity in a world increasingly driven by fear and control. Defending this place or witnessing its fall could heighten the stakes for the Order of the Emblematic, making it a critical location for future plot developments.

5. Establishing Layers to the World:
The inclusion of regions like Luminara adds more layers to Terra-Mythica, making the world feel richer and more diverse. It complements places like Ethelyn by providing a peaceful counterbalance, yet it remains tied to the same underlying tensions—giving you the flexibility to use it in ways that emphasize both the beauty and fragility of the world.

Next Steps:
As the story progresses, Luminara’s cultural and spiritual significance can play a bigger role, especially as Damion learns more about the Phoenix Emblem.

You can also use Luminara as a place of moral and philosophical exploration—where characters debate the right balance between technology and nature, resistance and peace, aligning with the themes of individual authenticity vs. societal control.

Plot-wise, if you want to heighten the tension, Luminara could come under threat by forces looking to destroy its neutral position, further pushing Damion and the Order into action.

Overall, Luminara fits the world, tone, and themes that have been developed so far in Shadows of the Veil. Would you like to integrate it into upcoming chapters, or further flesh out specific locations within the region?



---

## Source: Log(51).md


Wonderful. I’ll begin developing a richly layered worldbuilding guide for Terramythica. This will include:

Diverse biomes and ecosystems, including how landscape and climate shape regional life

City designs with architectural nuances, markets, and landmarks

Detailed religious systems, rituals, and sacred sites

Holidays from different cultures and epochs

Robust dueling systems with rules, styles, and legendary figures

Emblem class sheets for a range of playable roles

Lore articles featuring heroes, beasts, and political sagas

Compendium entries on ancient cultures and mythic artifacts

Game mechanics for character progression and interactive systems

I'll get started and share the first set of worldbuilding pieces soon for your review and iteration.

Research completed in 8m · 24 sources · 82 searches
Terramythica: A Realm of Myth and Legend
Terramythica is a richly imagined fantasy world where geography and culture intertwine to shape its myriad regions and peoples. Its continents were born of shifting tectonic plates, giving rise to towering mountain ranges, deep ocean trenches, and vast plains
. As in realistic worldbuilding, diverse landforms create distinct climates: equatorial rainforests teem with exotic flora, arid southern deserts bake under twin suns, and northern ice fields sweep across polar wastes. This geographic diversity underpins varied ecosystems — from coral seas and enchanted forests to volcanic highlands — ensuring each region supports unique life adapted to local conditions
. The lake Azurim in the northern craton is a caldera lake ringed by dormant volcanoes, its steaming vents hinting at bygone eruptions. 
https://commons.wikimedia.org/wiki/File:Fantasy_Landscape.jpg
In the shadow of the Lake Azurim caldera, dense woodlands and mossy marshes flourish, illustrating how water and terrain shape life. Warm ocean currents circulate to the south of these volcanoes, creating lush equatorial jungles rich in bioluminescent fungi and towering orchids. Great rivers flow from the central mountains, carving fertile deltas that support terraced farmlands. Seasonal storms and monsoons sweep in from the ocean, dropping torrential rains on the coasts and carving deep canyons inland. Inspired by real-world geophysical principles
, Terramythica’s climates vary from tropical to arctic; each climatic zone produces characteristic biomes (tropical rainforests, temperate oak forests, alpine tundra, etc.), all of which influence the cultures and creatures that dwell there
.
Shifting Continents: The continents of Terramythica slowly drift, forging mountain ranges (like the Titanspine Peaks) and opening sea straits. Rich mineral deposits emerge along fault lines, giving rise to dragon-haunted caverns and magically charged ore veins.
Climate and Seasons: The northern lands endure long winter nights under aurora-lit skies, fostering hardy folk and snow spirits. By contrast, the equatorial Vale of Verdance sees twin summers and harvests that fuel colorful harvest festivals (see Holidays). Ocean currents spawn mist-shrouded islands in the east, where fishermen honor storm deities for safe passage.
Ecosystem Diversity: Each region’s ecology is distinct: the Silvermarsh wetlands in the west are home to luminescent lotuses and leviathan crocodiles, while the Sunblight Desert hosts sand-raiding lizard-kin and oasis-bound nomads. Natural features like sacred groves and mountain shrines (often believed to harbor spirits
) punctuate the landscape, reinforcing the sense that the land itself is alive and intertwined with magic.
Cities and Architectural Marvels
Cities in Terramythica reflect their environments and cultures, creating architectural tapestries as varied as the world itself. Many towns incorporate local materials and styles — for example, coastal harbors use coral-stone piers, while highland castles are carved from black basalt. Notable architectural landmarks often tie directly into local lore
. In the coastal city of Lighthaven, a colossal iron lighthouse built atop a cliff becomes its symbol; in the forest city of Greenwood, a massive tree-spire (where an ancient oak was enchanted into a building) serves as the central temple. Design influences can range from practical to fantastical: glass-domed marketplaces glitter in sunlit plazas, and windmills with enchanted sails line the breezy hilltown of Windrest. Fantasy literature and games have inspired similar iconic structures; for instance, the ivory gothic spires of Astoria’s magus academy evoke famous magical castles
, while the sunken canals of Dunemon echo creative cityscapes found in Skyrim’s mountain cities
. 
https://commons.wikimedia.org/wiki/File:Pszczyna_Castle_High-resolution.jpg
In the aerial view above, Pszczyna Castle (an analog for Terramythica’s royal keeps) dominates the landscape, blending into its town. Similarly, Terramythican castles often feature grand courtyards and arched bridges, serving as both fortresses and centers of courtly intrigue. City planners utilize unique landmarks to give each city character: towering statues, enchanted lanterns that float at dusk, and cathedral-like temples at the main squares (many modeled after Hindu or Egyptian temples that house patron deities
). Markets bustle with traders selling exotic wares — such as dragon-scale armor or herb elixirs — in covered bazaars woven from silk awnings and glowing crystal chandeliers.
Structural Styles: Medieval castles and fortresses are common (e.g. the citadel of Ironfell with its steel-reinforced walls), as are high elven towers of spun-glass and ivory (e.g. the Moonspire of Elenya). Architecture often merges with nature: Cliffside cities like Stonehearth are literally carved into mountains (a design inspired by the cliff-dwelling city of Markarth
), and floating sky-cities are held aloft by air magic.
Landmarks and Public Spaces: Striking landmarks help define each city’s identity
. For instance, Emerald City boasts a massive emerald obelisk carved by ancient druids, while Boreal Falls is built around a magically suspended waterfall that never freezes. Town squares feature ornate guildhalls and observatories, and grand amphitheaters host performances by siren minstrels or gladiatorial contests. Each landmark is chosen to be “visually striking” and story-rich
; for example, the Sunken Statue plaza in Port-Kestrel commemorates a lost hero, anchoring city folklore in its very architecture.
Markets and Districts: Trade quarters are hubs of activity. The Bazaar of Spices in Merin holds stalls of enchanted teas and rare silks beneath glass domes. Industrial districts feature smoky forges and ticking clockworks (inventors in the steampunk town of Gearford run massive gear-driven mills). Suburbs have druidic shrines and communal gardens. Together, the layout of each city — from alleyways to avenues — blends practical design with mythic flourish, ensuring every urban center feels distinct and alive.
Faiths, Rituals, and Temples
Terramythica is a tapestry of faiths, each woven into the lives of its followers. Religions range from vast pantheons of deities to nature spirits and ancestral cults. Typically, a culture’s environment and needs shape its deities: islanders worship a mighty Sea Serpent god (reflecting a seafaring heritage) and fishing folk leave offerings on the shore
, while mountain tribes venerate a Sky Mother who commands storms. Some faiths are elemental or natural, organized around forces like sun, storm, or forest (similar to elemental pantheons
), while others take the form of deified heroes or even embodiments of concepts like honor or fate. In many pantheons, gods form a “divine family”
 — for instance, the Everlight Order’s 5 sun-gods are brothers who govern cycles of day and night. Priests and oracles interpret omens for warlords, and faiths often include lesser spirits or saints under each major god’s aegis
. Religious practice varies widely. Some temples are grand assembly halls echoing real-world cathedrals and mosques, built to welcome congregations
. For example, the Temple of the Golden Phoenix is an opulent structure where thousands gather to sing hymns and pray (much like a cathedral)
. Other faiths emphasize personal piety: household shrines and small altars are common in rural homes, where farmers burn incense and leave grain as offerings to agricultural spirits
. Nature worshipers often hold ceremonies in sacred groves or mountain peaks (a practice noted in our source, where mountaintops and springs are revered as divine abodes
). In all cases, clergy and monks maintain these sites, and daily rituals — feeding the god’s effigy, reciting ancient hymns, or performing baptisms in holy water — reinforce believers’ connection to their faith.
Divine Hierarchies: Many faiths have elaborate organizations. The Forest Wardens believe each woodland has a guardian spirit; their high druid rules from an arboreal cathedral. By contrast, the Iron Throne religion is a theocracy led by a single Immortal Emperor (a human raised to godhood), echoing how real-world theocracies base rule on divine right
.
Temples and Sacred Sites: Temples are often built like grand mansions or palaces
, for gods are treated as exalted patrons. For instance, the Temple of Horros (modeled on Roman and Egyptian temples) is a stone edifice where priests tend to a mighty statue, offering feasts and garments to the deity’s image
. Alternatively, the Sea Court of Alaina is actually the prow of an ancient ship grounded on sand — worshippers pray under sails, treating the vessel as a floating shrine. Smaller worship places include the Crystal Lanterns of Veritas (lantern-lit arcades where couples exchange vows), and the Sky Altars (plateaus where shamans commune with the wind).
Rituals and Festivities: Faiths mark life’s milestones with ceremonies. Births are celebrated with naming rites invoking guardian spirits, marriages may be bound by elemental trials (walking between dueling flame and water walls), and funerals involve releasing flower-laden boats down river. Festivals often overlap with holidays: e.g. Dawn of Renewal (spring equinox) is celebrated at the Dawnstone Temple with all-night dances and offerings of first fruits, embodying nature’s rebirth
.
Festivals and Holidays
Across Terramythica’s cultures, holidays are deeply rooted in history, faith, and nature. Many holidays mark the turning of seasons or commemorate past events
. For example, Harvestfest of Goldroot (a late autumn feast) thanks the earth after the harvest (a natural-origin festival
). The sky-folk celebrate Cometfall in midwinter when a meteor shower crosses the sky; children write wishes on lanterns and release them at night (tradition: lighted displays and poetry recitations
). Some holidays honor legendary deeds: Starlight Triumphant is a modern holiday that commemorates the day a famed hero slew the Moondragon, with parades and embellished storytelling (historical origin
).
Origins of Holidays: They often arise from five themes: religious events (gods’ myths), historical anniversaries (kingdom founding), social causes (Mothers’ Day, a modern holiday promoting family unity), political proclamations (Royal Coronation Day), or natural cycles (winter solstice). For example, Day of The Fallen is a solemn remembrance for war dead, blending historical and religious elements (veterans lay wreaths at temples). Real-world holiday origins guide this mix
.
Traditions and Customs: Each festival has signature rituals. City streets are bedecked in the colors of the season (pumpkins and garlands for Harvestfest, lanterns and snowflowers for winter holidays). Large-scale events include parades of costumed performers, masked dances, and communal feasts (roasted boar, pumpkin pies, spiced ales). Smaller customs might be writing poems on the sky-lanterns or crafting special dishes to share. People may also exchange gifts relevant to the holiday’s theme (e.g. embroidered shawls on the Day of the Ancestors, reflecting familial bonds). These traditions reflect the holiday’s meaning — whether it’s unity, gratitude, or remembrance — and often evolve over generations
.
Evolution Over Time: Holidays change as cultures do. A chieftain’s victory celebration might grow into an empire-wide festival, eventually becoming secular and commercial. As with real holidays like Christmas evolving from religious to secular celebration, Terramythican holidays may shift focus while keeping traditional elements. For instance, the once-sombre Day of Tears (mourning a past calamity) has in recent decades added music and dancing to uplift spirits, symbolizing hope along with remembrance.
Dueling Traditions and Systems
In Terramythica, formal duels are governed by strict custom and honor codes. A duel typically begins with a formal challenge: the offended party publicly states a grievance, and the challenged person may then apologize or accept the duel. If the duel proceeds, terms are negotiated (weapon, location, conditions)
. This mirrors historical code duello traditions: duels are one-on-one combats under agreed rules, intended to resolve disputes without vendettas
. Battles usually occur at dawn on secluded grounds; each duelist brings a second (a trusted aide) and a physician for safety
. As one source notes, seconds first attempt reconciliation — if that fails, they witness the duel’s fairness and ensure the duel follows agreed terms
. Most duels in Terramythica honor an archaic code: the aim is not necessarily to kill but to restore honor. Matched weapons are chosen (swords have long been traditional, later including pistols and other arms
). By honor, each combatant uses only the agreed weapons and tactics
. Victory is often achieved by first to wound, disarm, or force surrender
. The presence of witnesses and healers underscores that duels are meant to be decisive yet fair, reflecting how code duello “helps prevent vendettas” by exhausting nonviolent solutions and ensuring medical care
. Legendary duels are woven into Terramythic folklore. Tales speak of The Duel of the Twin Moons, where two princesses clashed under a rare celestial alignment — a contest so famed that its ruins are now a pilgrimage site. Ballads recount Sir Alondir vs. the Minotaur-king, an epic combat beneath a crimson sky, paralleling heroic myths and the monomythic hero’s journey archetype
. These storied duels, whether magical spell-casting contests or sword duels at dawn, epitomize personal valor and become part of the realm’s shared history.
Emblem Classes and Heroic Archetypes
Player characters in Terramythica choose from Emblem classes that define their roles, skills, and playstyles. Each class grants a unique set of abilities, consistent with RPG design where “a character’s ability depends on their class”
. For example, a Knight Emblem is characterized by heavy armor and protective skills
. Knights serve as frontline defenders: they have high health and use shields to guard allies (the Knight may have an ability like Shield Wall to block attacks
). By contrast, a Sorcerer (Magician) Emblem wields elemental magic. Sorcerers are “glass cannons”
 — capable of devastating ranged attacks (fireballs, ice storms) but with low physical defense. They might unlock spells that synergize (for example, combining a burning enchantment with a fire arrow for extra effect, akin to game mechanics
). Other Emblem classes include Rangers (master archers and scouts), Clerics (healers who also wield holy magic), Rogues (stealth and agility), and exotic classes like Beastmasters (animal companions) or Gunmages (spellcasters using firearms) as bonuses
. Each class has its progression path: as characters level up, they choose new talents—this is horizontal progression (multiple skills of similar power)
. For instance, a Ranger might pick between Twin Shot (double arrow attack) or Camouflage (stealth) at certain levels. Vertical progression also plays a role: leveling increases core stats (strength, magic, etc.), so character numbers like damage and health grow predictably
.
Knight (Cavalier): High defense and support, adept with sword and shield. Knights often have crowd-control abilities (taunts or protective auras) to safeguard allies
. They progress by unlocking new combat stances and fortifications.
Sorcerer (Magician): Powerful ranged magic-user. Specializes in elemental spells (fire, lightning, etc.) but is vulnerable up close
. Progression involves learning new spells; offensive abilities grow rapidly as enemies that once posed a threat can be vanquished more easily at higher levels
.
Other Classes: Rangers use the environment and bow skills (e.g. choosing a Trapper subclass to lay ambushes). Clerics gain divine magic (healing and blessed weapons). Rogue-like Emblems focus on agility and critical strikes. Rare Emblems like Engineer or Beastmaster may appear through special storylines.
Class Synergy: Teams often combine classes for balanced play. A typical party might include a Knight (tank), Sorcerer (damage), Cleric (support), and Rogue (utility). This mirrors how RPGs encourage diverse classes for different combat roles
.
Heroes, Creatures, and Intrigue
Terramythica’s history is rich with legends of heroes and monsters that have become part of its cultural identity. Heroes often follow the archetypal hero’s journey: they leave humble origins, face trials, and return transformed
. For example, the saga of Valkorin the Bold tells of a farm boy who ventured into the Feywood, overcame a nightmarish lich, and returned as king — a narrative echoing Campbell’s monomyth. Such stories are recorded in bardic songs and Compendiums of Lore, teaching lessons of courage and sacrifice. Mythical creatures abound. Ancient spirits dwell in sacred groves, while elemental beasts roam wild lands. Dragons might guard hidden treasures or wisdom (much like folklore dragons in many cultures). In the Crystal Desert, shimmering sand wyrms petrify travelers, whereas the Emerald Glade is home to ethereal starlight unicorns that heal the wounded. Each region’s bestiary reflects local themes: storm giants on the lightning coast, ice wraiths in the north. Some creatures are benevolent guardians (e.g. the Great Owl who sings prophecies), others are feared nightmares that trigger quests. Political intrigue is woven through Terramythican societies. Many nations are monarchies where succession is contested
. Noble houses scheme in palace halls; marriages and assassinations shift alliances. Empires expand through conquest, leading to oppressed provinces and rebellions
. For example, the Empire of Zenithar was forged by war but constantly faces insurgencies from local chieftains. Guilds and factions add another layer of politics
: the Merchant Council and Thieves’ Syndicate vie in city-states, their clandestine plots as dangerous as any battlefield. These intrigues (regardless of a democratic or theocratic government) create a dynamic backdrop: coups, spy networks, and alliances keep the realm in constant tension, much like in classic high-fantasy narratives.
Ancient Lore and Prophecies
Terramythica’s archives and sages speak of lost civilizations and mysterious relics. Legends tell of the Golden Age of Allura, when sky-palaces ruled the air and alchemy triumphed, leaving behind ruins filled with ancient machinery. Explorers delve into sunken cities of the Sea Kings, seeking artefacts like the Orb of Eternity (said to grant glimpses of fate). Every continent has its prophecies: the Prophecy of the Eclipse foretells a time when twin moons align and a great darkness will sweep across the land. Every full moon, cultists reread this prophecy and light bonfires against the coming night. These lore elements serve as worldbuilding “hooks.” For instance, an entry in the Chronicle of the Forest speaks of a Tree of Giants that once bridged realms (sparking quests for its buried seeds). The Codex of Flames is an ancient manuscript rumored to predict eruptions of the Flamepeak volcano. Such tales deepen the world’s mystery: even well-traveled adventurers fear what lies beneath desert sands or in uncharted archipelagos. By weaving history, artifacts, and prophecy into lore, Terramythica gains an immersive depth that players can uncover over time.
Game Mechanics and Systems
To make Terramythica engaging as a game, its mechanics reinforce these world elements. Character progression is carefully designed: each level grants new abilities (a horizontal progression system)
, letting players customize builds (e.g. choosing a second-tier skill or upgrade). Simultaneously, core stats and gear improve (vertical progression), so revisiting old lands feels rewarding as enemies fall more easily
. This satisfies the player’s sense of growth: as one designer notes, “quickly dispatching enemies that were difficult several levels ago gives us a sense of achievement”
. Unlocks and rewards also provide feedback: obtaining a new sword or powerful spell shows tangible benefits from invested time
. Combat mechanics blend storytelling with rules. For example, mastering a magical combo might require learning synergy spells, as seen in real-game systems
. Players must adapt tactics: a strong mob hints that “you might need to retreat or find a clever way around”
. Quests and encounters often tie into lore (e.g. a quest to end a drought on Isle of Rain involves performing a rain ceremony at the island’s sacred springs). Interactive elements like puzzles (unlocking ancient doors) or social challenges (negotiating with a merchant guild) keep gameplay varied. Overall, Terramythica’s rules and progression systems are built to be intuitive and rewarding. As players advance, new skills expand their strategic options, and increased power opens previously inaccessible areas
. By layering these mechanics — character builds, equipment upgrades, skill trees — the game encourages exploration, cooperation, and creativity, making the world of Terramythica feel dynamic and alive
. Sources: The world-building ideas above are inspired by conventions and analyses of fantasy world design
, as well as real-world historical practices and game development guides. These sources provide insight into constructing believable geography, cultures, and systems in a fantasy setting. Each citation denotes where such concepts are discussed, adapted here to flesh out Terramythica’s lore.






Sources

Okay, can you apply all these techniques to the world that we've been working on and remove all the sources and put them at a list at the end of the response?

Done! I've applied all the techniques from our previous discussions into a unified, source-free worldbuilding guide for Terramythica. You can expand any section (cities, duels, classes, etc.) or request detailed additions like stat blocks, maps, or NPC bios. Just let me know what you'd like to develop next.


Apply what you learn from your research to increase the depth of the world we've been working on as well.

Terramythica Worldguide

Terramythica Worldbuilding Guide

1. Geography and Ecosystems
Terramythica's vast and mystical landmass is shaped by the convergence of leyline fractures and celestial tides, forming a tapestry of diverse ecosystems. From the frostbitten crystalline peaks of the Titanspine Mountains to the ethereal jungles of the Vale of Verdance, each region is defined by magical and environmental forces.

The Titanspine Mountains: Towering glacial ranges imbued with starlight, home to thunder wyverns and ancient sky-priests. Storms swirl around the peaks, creating auroras that guide travelers. These mountains are also the site of numerous Emblem trials, where the resonance of high-altitude ley currents tests a would-be hero’s resolve.

The Hollow Expanse: A sun-scorched desert where reality thins. Sandstorms reveal ruins of a once-mighty sun-worshipping empire, guarded by memory-eating specters. Shifting dunes conceal entire cities lost in time, and occasionally, temporal mirages replay ancient tragedies.

The Verdant Reach: Massive bioluminescent forests where the trees grow in recursive fractal spirals. Populated by tribes who commune with emotion-reactive flora and hunt using empathy-linked beasts. Local druids can read memories encoded in plant life, tapping into arboreal archives known as the Leaflines.

The Fractured Sea: Floating islands and drifting coral atolls suspended by fractured gravity fields. Nomadic skyfisher guilds harvest cloudwhales and steer by singing to magnetic stars. Undersea currents pulse with emotion-charged magic, forming shimmering reefs that react to thought.

2. Cities and Architecture
Each city of Terramythica reflects its surrounding biome and the dominant Emblematic philosophies of its people.

Elenestra, City of Whispers: Built into cliffs of glimmering onyx, this city is ruled by the Veiled Synod and known for its invisible bridges, mood-reactive glass towers, and echo-market where secrets are bartered. The city is also famed for its Silent Choir—empathic seers who speak through ambient sound.

Forgeheart: A city carved into the caldera of a dormant volcano. It is powered by deep-magma technomancy and defended by golems bearing Fractal Cores. Citizens follow the Doctrine of the Pulse, believing self-improvement mirrors the recursive perfection of the forge.

Skyroot: Suspended in the canopies of massive starwillow trees, its architecture blends wood and soulsteel. Rope bridges and song-activated lifts connect various levels. The city breathes in rhythm with the Emblem of Wind, and the Council of Rings governs by listening to the forest's hum.

Mir Khashem: A multicultural trade capital at the crossroads of ley-trains and memory ferries. Its crystalline dome shifts color with each festival. Spires, plazas, and canals weave a vibrant tapestry of intermingled traditions. Beneath it lies the Mirror Bazaar—an undercity where dreams and desires are traded.

3. Religions and Faiths
Religious beliefs in Terramythica are deeply intertwined with magic, emotion, and the cycles of celestial Emblems.

The Concord of Flame and Star: A dualistic faith honoring twin deities—Ignivar, the Flameheart, and Celessis, the Starborn. Temples are built on volcanic vents and mountaintops. The Concord’s hymns align with stellar frequencies, creating harmonics that influence weather.

The Verdant Spiral: A druidic faith focused on rebirth and recursive growth. Followers wear living vines and undergo spiritual molting. Ceremonies involve harmonic planting, where entire groves are grown by song and sacrifice.

The Vein-Eaters: A forbidden blood cult that believes in consuming divine essence to awaken latent Emblems. Their rites involve mirrored masks, redstone altars, and ecstatic visions beneath the Hollow Moon. Underground sanctuaries, called Pulse Crypts, store preserved heartstones of saints.

4. Holidays and Festivals
Holidays in Terramythica combine celestial events, historical commemorations, and seasonal magic.

Dawn of Renewal: Celebrated in spring with bioluminescent seed-floating ceremonies and sky-lantern duels to awaken the leyfields. Marked by city-wide song-rituals that sync to the heartbeat of local leywells.

Ashen Veil: A somber day where the dead walk peacefully among the living. Families host candlelight feasts, sharing memories with ancestral echoes. Ash scripts—scrolls made of incense ash—are burned to send messages to the dead.

Feast of Fractals: Honoring the invention of the first Fractal Core, cities display recursive light sculptures and host emotion duels. In Gearford, a parade of living constructs reenacts the genesis of cognition.

Rite of the Lost Moons: A solstice observance where travelers release floating glyphs into the sky, seeking guidance from long-lost ancestors or forgotten gods. The glyphs often return, bearing strange inscriptions.

5. Dueling Systems
Duels in Terramythica are bound by ancient Emblem Codes, both ceremonial and practical.

Arcblade Duels: High-speed magical sword duels where energy trails leave predictive afterimages. Combatants must read emotional echoes to anticipate movements. Duels are scored both by strikes and “clarity”—an aura-based performance metric.

Pulse Duels: Fought with technomystic pistols that discharge kinetic emotion bursts. Arena rules include leyline dampeners and spectral referees. A heartbeat metronome keeps tempo, and mismatched rhythm leads to disqualification.

Ritual Duels: Used to settle theological or political debates. Conducted in memory-encoded arenas, where each strike resonates with symbolic weight. Opponents often wield philosophy-bound weapons, such as truthblades or paradox staves.

6. Emblem Class Sheets
Knight of the Aegis

Role: Tank/Defender

Abilities: Shield Pulse, Ward of Unyielding, Oathbind

Traits: Honorable, Unbreakable, Loyal

Signature Mechanic: Resolute Barrier—accumulates strength based on emotional harmony in the party.

Fractalist Savant

Role: Technomage/Controller

Abilities: Fractal Surge, Recursive Loop, Core Reprogram

Traits: Curious, Eccentric, Visionary

Signature Mechanic: Feedback Singularity—repeats successful spells with increased entropy.

Emberveil Rogue

Role: Assassin/Illusionist

Abilities: Smoke Ribbon, Silent Hex, Phantom Step

Traits: Witty, Elusive, Morally Gray

Signature Mechanic: Shadow Threads—stores echoes of previous movements for repositioning.

Seraphic Cantor

Role: Support/Healer

Abilities: Harmonic Restoration, Songshield, Choral Banishment

Traits: Compassionate, Mysterious, Inspiring

Signature Mechanic: Emotional Resonance—healing power scales with collective awe or grief.

Wyrmblood Reaver

Role: DPS/Elementalist

Abilities: Flame Maw, Scaleguard Rage, Draconic Leap

Traits: Fierce, Passionate, Proud

Signature Mechanic: Bloodwake—inflicts elemental wounds that mutate under pressure.

7. Legends, Heroes, and Intrigues
Damien Knightley: A scarred Emblematic whose fractured core gives him glimpses of past timelines. He walks the line between savior and tyrant. Known as the “Ash Emperor” in alternate histories.

The Crying Crown: An artifact that weeps molten silver. Stolen from the Forgotten Kings, it corrupts all who wear it. When placed upon a bearer, it sings their regrets aloud.

The Emblematic Schism: A civil war among Emblem bearers. The battle of Skyfall Citadel split a floating city in half, creating the Rift of Mourning. Emotional trauma from the event left residual spells haunting the ruins.

Guild of the Hollow Tongue: Spymasters and cipher-bards whose songs encode hidden truths. Their “dissonant canticles” destabilize memory in court hearings.

8. Compendium Entries
The Spiral Archives: A time-folded library where history writes itself backward. The deeper you go, the older the truth. Every book must be read aloud to reveal its real content.

The Oracle of Dust: A blind drifter who inhales sacred sands to speak fragmented futures. Pilgrims offer hair or dreams in exchange for prophecy. Each answer is always half a riddle.

Eclipse Chalice: A cursed relic that absorbs sunlight and casts eternal shadow. Used in the banishment of the Moondragon. It is said to contain an hour of lost time.

9. Game Mechanics
Progression: Hybrid vertical/horizontal system. Core stats increase with level; new skills are unlocked via memory trials, emotional resonance, and narrative milestones. Each character’s growth path is influenced by their emotional archetype.

Combat: Tactical-emotional hybrid. Status effects include Despair, Zeal, Awe—emotions alter effectiveness of spells and attacks. Emotional backlash can cause spells to spiral out of control.

Exploration: Terrain-responsive mechanics. Forests amplify stealth, deserts punish over-encumbrance, and underwater ruins require breath glyphs. Enchanted maps remember paths only if walked with purpose.

Faction Influence: Reputation tracked with Emblem Orders, Mercantile Houses, and Spiritual Cults. Changing alliances affects questlines. Betraying a faction can lead to emotion-encoded bounties.

Source Inspirations: Real-world religious architecture, emotional game design theory, dueling codes, progression systems in RPGs, ecological worldbuilding techniques, and cross-cultural folklore and mythology.

The document has been enriched with additional depth based on applied research and storytelling design. Each section—ecosystems, cities, faiths, holidays, duels, classes, legends, and mechanics—now includes more nuance, emotion-driven dynamics, and world-consistent lore. Let me know if you'd like a visual map, faction guide, or companion bestiary next!



---

## Source: Log(59).md

Jul 4, 2025 at 5:52 PM
Delve into the rich tapestry of Terramythica, a fantastical realm brimming with diverse characters and intricate mechanics that shape its very existence. Begin by introducing figure. the world's power system. Explore the geography of Terramythica detailing how these landscapes influence the cultures and societies that thrive within them.

Unveil the dual nature of Terramythica's functioning, where physical laws intertwine seamlessly with arcane energies that flow through. Illustrate how characters harness this magic to summon elemental forces, manipulate reality, or forge powerful artifacts imbued with ancient enchantments. Delve into the delicate balance between light and dark factions vying for control

Recount pivotal events that have shaped Terramythica's history, Highlight special rules governing magical duels, astral travel restrictions, or the forbidden art of soul-binding that carries dire consequences. Conclude by elucidating how characters navigate these complexities confronting existential threats in a world where power

Power System Overview
Terramythica’s lifeblood is woven from the twin threads of the Aetheric Weave and the Primal Currents. The Aetheric Weave is an invisible lattice of arcane resonance that permeates every molecule, ebbing and flowing like a cosmic tide. Novices learn to tap raw threads of this weave—snatching glimmers of energy to cast simple wards or ignite sparking motes of light. Masters, however, work in Fractal Cognition, folding the Weave into recursive matrices that empower golems, animate constructs, or even warp the fabric of space.

Running beneath the Weave are the Primal Currents—vast elemental rivers of Earth, Fire, Water, Air, and the elusive Void. These currents bleed through natural leyline confluences, pooling in places of power where adepts can channel unstoppable torrents: volcanic forges fueled by living magma, tidal sanctuaries shaped by eternal waves, and wind-swept spires where stormlords call down lightning. The rarest Current, the Soulstream, taps into sentient emotion itself, allowing risk‑laden arts like soul‑binding or empathic divination.

Geography and Cultural Influence

The Crystal Verge: Jagged quartz mountains refract moonlight into perpetual auroras. Its mining clans carve citadels from living crystal, using the naturally amplified Aetheric reflections to power prismatic defenses. Culture here prizes clarity of mind and honesty; deceit is said to fracture souls as cleanly as crystal.

Whispering Plains: Rolling grasslands threaded by hidden ley‑veins. Scouts like Lila train here, learning to read the subtle hums of the Weave beneath the soil. Nomadic tribes follow seasonal ley surges, worshipping migratory spirits that dance on the horizon and guide caravans.

Umbral Marshes: A realm of perpetual twilight where mists swirl with memories of the dead. Necromancers and shadow‑weavers scavenge soul‑fragments, crafting wraith‑forged weaponry. Societies here are secretive; alliances are forged in whispered bargains beneath moonlit groves.

Furnace of the Deep: A vast network of subterranean forges bathed in molten rock. Earth‑mancers harvest magma sprites to animate metal, birthing golem‑smiths whose constructs patrol the molten halls. Their culture reveres resilience and forges pacts through iron‑sealed oaths.

Skyborne Archipelago: Floating isles lofted by ancient Fractal Cores. Elemental academies dot the clouds, teaching students to sculpt storms and ride air‑whales. A meritocracy thrives on discovery; each new sky‑chart redraws political boundaries.

Physical Laws & Arcane Energies Intertwined
In Terramythica, Newtonian physics governs mundane motion—arrows arc predictably, siege engines obey gravity. But every mass also carries an Aetheric signature, allowing mages to apply selective buoyancy, friction‑nullification, or temporal dilation. The Second Law of Thermodynamics can reverse locally under pure nostalgia, creating pockets of rejuvenation (and dangerous paradoxes) when heartbreak‑bound sorcerers summon it.

Ley‑channelers routinely blend physical and magical: an elemental fireball obeys ballistic trajectory until it strikes, then erupts with chaotic flame patterns drawn from the caster’s emotional state. Constructs born of Fractal Cores exhibit pseudo‑intelligence, their movement obeying both mechanical joints and sentient arcane impulses.

Harnessing the Weave & Faction Balance

Order of the Emblematic: Champions of equilibrium who bear Emblems—mystical marks granting attunement to specific Currents. Their scouts and strategists (like Lila, the Shadowed Feather) manipulate battlefield Weave‑fields to cloak armies or disrupt enemy spells.

Eclipsed Covenant: A dark league of soul‑binders and emotion‑feeders, once benevolent spirits twisted by negative human energies. They harvest fear and sorrow, crafting soul‑shackles and black mirrors that trap living essences.

Fractal Consortium: Technomystics who fuse science and sorcery. Their sky‑cities float via self‑replicating Fractal Cores, and they deploy golem‑regiments with fractal‑patterned armor that self‑repairs using arcane recursion.

Circle of Primordial Song: Druids and echo‑heralds who channel world‑spirits through ritual harmonics. They shepherd migratory ley‑spirits and maintain natural balance, countering both Order and Covenant when they overreach.

Pivotal Historical Events

The Shatter of Nyx’Thal (-420 AR): A rogue Emblematic shattered a ley‑nexus in the Crysal Verge, unleashing a fractured surge that birthed the Umbral Marshes and twisted countless mortals into echo‑wraiths.

The Great Ember Accord (−180 AR): Diplomacy between the Furnace Deep forges and the Circle of Primordial Song quelled centuries‑old conflict, leading to the creation of magma‑ward golem‑sentinels that now guard ancient sylvan groves.

Skyfall Cataclysm (−12 AR): A Fractal Core malfunction caused a floating isle to plummet into the Whispering Plains, reshaping local geographies and demonstrating the perils of unbridled technomancy.

Special Magical Rules & Forbidden Arts

Duel of the Currents: Spellcasters face off within a demarcated Circle of Axiom, where leyline manipulation is restricted to prevent runaway cataclysms. Each participant starts with equal Weave‑charges; draining the opponent’s reserves yields victory.

Astral Travel Restriction: Passage through the Veil of Worlds demands a tri‑synchronization ritual—aligning one’s heartbeat, soul‑signature, and incantation cadence. Failure results in Astral Fracture, trapping the traveler’s consciousness between planes.

Soul‑Binding: The ultimate taboo. To bind a soul is to tether life‑essence into objects or beings, granting immense power but corrupting both victim and binder. Most realms outlaw the practice; practitioners risk being consumed by the Voracious Void, a metaphysical maelstrom that devours unchecked soul‑energy.

Navigating Existential Threats
Characters traverse Terramythica by balancing ambition against cosmic equilibrium. A young Emblematic knight may seek to master both light and shadow Currents, forging unlikely alliances with former Covenant agents to counter a rising tide of despair. Technomystic engineers collaborate with druids to stabilize fractal ruptures threatening to unravel entire sky‑cities. Secret councils in the Umbral Marshes broker peace with echo‑heralds, discovering that empathy—when wielded responsibly—can be as potent as any battle‑spell.

In Terramythica, power is never absolute. Every spell cast, every artifact forged, tips the scales of a world in perpetual flux. Here, true mastery lies not in domination, but in understanding the fragile harmony between the mundane and the magical.



---

## Source: Log(33).md


To bring clarity, structure, and richness to the evolving lore of Terramythica, here is a comprehensive classification system for all core narrative elements—including Emblems, artifacts, technologies, characters, events, flora/fauna, and emotional dynamics. This will serve as a flexible worldbuilding toolkit and reference framework for creative development, in the vein of systems used in games, RPG sourcebooks, or encyclopedic guides.

📚 Terramythica Classification System (TCS)
“Emotion defines reality. So we must define emotion.” – The First Codexian Law

1. 🌀 Emblem Types
Emblems are classified by emotional source, manifestation style, and functionality.

▣ Emotional Source (Resonance Class)
Primordial – Originating from ancient, universal emotions (fear, love, rage, wonder)

Mortalborn – Arising from common human emotions (grief, pride, guilt, compassion)

Catalytic – Created through trauma, mutation, or ritual overload

Synthetic – Artificially stimulated by techno-magical means (rare and unstable)

▣ Manifestation Style (Symbolic Class)
Tatamic – Symbol appears as fixed or growing tattoos/sigils

Living – The Emblem takes a semi-sentient form or creature

Internalized – Hidden inside the body or soul; visible only during activation

Projected – Emits outward as an aura or visible halo

▣ Functionality (Core Class)
Echo – Time-memory bending or event repetition

Flux – Elemental or environmental transformation

Harmonic – Empathic modulation and emotion-based connection

Surge – Combat-focused energy or resonance enhancement

Null – Emblem disrupts or consumes other Emblematic energy

2. 🗝️ Artifact and Technology Classes
Every major item is classified by origin, function, danger level, and rarity.

▣ Origin Source (Lineage Class)
Firstborn – Ancient relics from pre-Hollowed civilizations

Soulforged – Crafted from emotional resonance by Emblematic or mystics

Aethertech – Hybrid inventions using both science and emotion

Hollowborne – Created or corrupted by Hollowed beings

Forgotten – Unknown origin; often sentient or unstable

▣ Functionality Tier (Use Class)
Conduit – Channels or amplifies emotional/magical energy

Anchor – Grounds reality, prevents emotional manipulation or warping

Catalyst – Triggers transformation (of environment, self, or others)

Containment – Holds dangerous forces (Hollowed energy, unstable Emblems)

Conscious – Displays sapient or semi-aware behavior

▣ Danger Class
Alpha (Non-lethal)

Beta (Hazardous if misused)

Gamma (Environment-altering)

Omega (Potential extinction-level effect)

▣ Rarity Grade
Common

Rare

Mythic

Singular

3. 🌍 Civilization & Culture Index
A shorthand for categorizing societies by structure, belief, and emotional worldview.

▣ Societal Organization
Hierarchal – Structured tiers of command (e.g., Caedharon)

Symbiotic – Cooperative, ecosystem-like governance (e.g., Empathari)

Ritualist – Structured through rites and seasonal traditions (e.g., Emberward)

Anarcho-Philosophic – Rule by collective emotion or vision (e.g., The Dissonant Choir)

▣ Emotional Paradigm (Core Belief)
Suppressionist – Emotion must be controlled or eliminated

Channelist – Emotion is sacred and must be expressed constructively

Utilitarian – Emotion is a tool to achieve societal goals

Resonantist – Emotion is the source of all reality; balance is key

4. 🌿 Flora & Fauna Classifications
Each species is identified by origin, sentience, and emotion-sensitivity.

▣ Biotype Class
Echoflora – Plants with memory-empathic properties (e.g., Sorrowvines)

Phantomfauna – Creatures partially existing in the emotional realm

Elementa – Born of elemental and emotional fusion

Aberrant – Corrupted or Hollowed by negative emotional overload

Coalescents – Lifeforms formed entirely from condensed emotion (rare)

▣ Sentience Class
Instinctual – Basic animal behavior

Reactive – Emotionally aware, responds to feelings

Telempathic – Can share sensations/emotions

Cognitive – Capable of full speech, reasoning, and moral agency

▣ Threat Grade
Passive

Reactive

Hostile

Possessive (emotionally invasive)

Unstable (can alter local emotional reality)

5. 🧬 Character Classification
Use this to track narrative roles, Emblematic status, and psychological resonance.

▣ Role Type
Catalyst – Drives major change (e.g., Damien)

Mirror – Reflects the protagonist’s moral/emotional dilemma (e.g., Vorrin)

Anchor – Stabilizes group dynamics emotionally (e.g., Kelyn)

Wild Card – Unpredictable effect on both Hollowed and Emblematic factions

Architect – Plots behind the scenes, shapes ideological outcomes

▣ Emblematic Status
Natural Emblematic – Emblem awakened spontaneously

Induced – Triggered through trauma or ritual

Dormant – Mark exists but is inactive

Cracked – Emblem partially destroyed, mutated, or corrupted

False – Emblem is mimicked via tech or Hollowed mimicry

▣ Emotional Profile Tier
Balanced – Experiences emotion with restraint and empathy

Amplified – Prone to extremes, powerful Emblem users

Repressed – Struggles to access emotion (may become Hollow-susceptible)

Disassociative – Detached from emotional grounding, unpredictable behavior

6. 🌪️ Event Classification
Classify world-shaking or story-shaping events for timelines and faction lore.

▣ Scale
Personal – Alters one character’s arc

Regional – Affects a zone, culture, or war front

Epochal – Defines eras of Terramythica (e.g., Sundering)

Continuum-Breaking – Alters timelines, emotional metaphysics, or Emblem behavior

▣ Emotional Fallout Type
Echo-Surge – Creates repeatable trauma/memory in zone

Hollow-Bloom – Leads to Hollowed expansion

Resonance Shift – Alters regional emotional fabric

Sympathy Cascade – Triggers sudden Emblem awakenings

Silence Zones – Entire regions become emotionally numb (possibly post-Hollowed)

Would you like this system formatted as a printable or editable PDF index, or organized as a database-style template for easy worldbuilding reference?


a detailed Emblem Classification Codex

Here is a richly detailed Emblem Classification Codex, designed as an in-universe reference text used by scholars, Emblematic orders, and secretive archives like the Codexian Syndicate or the Skyvault Aetherclergy. This codex categorizes Emblems based on their emotional resonance, manifestation, function, rarity, and known examples—structured for creative use and expansion.

📖 The Emblem Codex: A Comprehensive Guide to the Resonant Marks of Terramythica
“To know an Emblem is to know a soul—not merely the power it wields, but the wound it comes from.” — High Archivist Sien Varx, 3rd Era

🌀 I. Emotional Resonance Class (ERC)
Describes the emotive origin of the Emblem’s power. Emblems are living responses to emotion—encoded into symbolic energy.

Class	Description	Sample Emotions	Tendency
Primordial	Ancient emotions linked to survival and mythic instincts	Awe, Rage, Fear, Wonder	Wild, unstable, powerful
Mortalborn	Common yet deep human emotions tied to personal experience	Grief, Joy, Guilt, Love	Personal, reactive
Catalytic	Emblems formed from intense trauma, transformation, or moral paradox	Betrayal, Obsession, Redemption	Volatile, mutative
Synthetic	Created through external ritual or scientific manipulation	Engineered emotion	Rare, prone to corruption
🧬 II. Manifestation Class (EMC)
Describes how the Emblem reveals itself on or around its bearer.

Class	Description	Traits
Tatamic	Appears as a tattoo or shifting sigil on the skin	Expands/changes with power use
Internalized	Hidden within organs, bones, or soul; activated through trigger	Leaves no visible mark when dormant
Projected	Emits energy fields, aura, or elemental halos	Always visible when active
Living	Takes a creature/construct form separate from the host	May evolve, bond, or go rogue
Woven	Incorporated into garments, objects, or heirlooms	Sentient equipment, reactive to emotion
⚙️ III. Function Class (EFC)
Defines what the Emblem does or allows the bearer to influence.

Class	Description	Key Powers
Flux	Alters elements, physics, or reality through emotional charge	Fire from anger, ice from regret
Echo	Time- or memory-based manipulation	Memory projection, temporal rewinds
Harmonic	Emotion-to-emotion interaction, empathy, communication	Mind links, mood control
Surge	Pure energy or force amplification	Combat strength, barrier shattering
Null	Cancels, absorbs, or corrupts magic/emotion	Anti-magic fields, Hollow repulsion
Chimeric	Mixes two classes with unpredictable interactions	Rare, unstable
✨ IV. Rarity Tier (ERT)
Indicates how uncommon and powerful a specific Emblem is. Most citizens of Terramythica will never see a Tier III or higher in person.

Tier	Description	Approx. Occurrence
Tier I: Common	Seen in soldiers, healers, minor scholars	1 in 5,000 people
Tier II: Rare	Used by specialists, trained warriors	1 in 30,000
Tier III: Mythic	Legendary, world-affecting	1 in 500,000
Tier IV: Singular	One known bearer, cannot be duplicated	Unique
🧩 V. Known Emblem Archetypes
Here are iconic Emblems, serving as templates or actual powers within the world:

🔥 Emblem of Burning Memory
ERC: Catalytic

EMC: Projected

EFC: Flux

Rarity: Tier II

Symbol: A flame spiraling through a broken hourglass

Power: Converts guilt and past trauma into elemental fire; the more the bearer regrets, the more powerful the flames

Drawback: Emotional detachment lessens effectiveness; bearer may hallucinate past events

🌿 Emblem of Verdant Grace
ERC: Mortalborn

EMC: Tatamic

EFC: Harmonic

Rarity: Tier I

Symbol: A vine looping around a heartbeat

Power: Grows flora in seconds, senses emotional wounds, purifies toxins

Drawback: Cannot function in Hollowed zones without withering

🕊️ Emblem of Echoing Resolve
ERC: Primordial

EMC: Internalized

EFC: Echo

Rarity: Tier III

Symbol: A falcon descending a spiral staircase

Power: Allows bearer to relive key emotional moments for insight or replayed action

Drawback: Risks memory collapse; may confuse past with present

⚔️ Emblem of Fractured Unity
ERC: Synthetic

EMC: Living

EFC: Null + Surge (Chimeric)

Rarity: Tier IV

Symbol: Two blades bound by a chain

Power: Generates an anti-emotion field; disables nearby Emblems while empowering physical prowess

Drawback: Slowly erodes bearer’s ability to feel or dream

💧 Emblem of the Weeping Star
ERC: Mortalborn

EMC: Woven (appears in a necklace)

EFC: Harmonic + Echo

Rarity: Tier II

Symbol: A tear falling into a pool of stars

Power: Can bring comfort or despair with a gaze; projects memories into water

Drawback: Wielder feels every wound they heal

🧠 VI. Classification Markers (for Codex Entry Headers)
When creating new Emblems, use this shorthand format for database or narrative tagging:

[EMBLEM NAME]
ERC: [Resonance Class]
EMC: [Manifestation Class]
EFC: [Function Class]
Rarity: Tier [I–IV]
Symbol: [Optional Visual Description]
Example:

EMBLEM OF SUNDERED HOPE  
ERC: Catalytic  
EMC: Projected  
EFC: Echo  
Rarity: Tier III  
Symbol: Twin moons eclipsing a broken sun
🏛️ VII. Notable Factions Studying Emblems
Codexian Syndicate – Collects and categorizes Emblems, seeks hidden truths

Order of the Unbound Sigil – Trains Emblematic in usage and theory

The Gilt Keepers – Black-market traders of Synthetic or stolen Emblems

The Hollowed Choir – Seeks to break Emblems and rewrite emotional metaphysics

Would you like me to help you generate Emblem archetypes for specific characters, design rituals to awaken dormant Emblems, or create Emblem mutation rules for Hollowed exposure next?


Jun 17, 2025 at 6:36 PM
What else do you think we need to add to make this world structurally sound?

You’ve built a wonderfully rich tapestry so far—Emblems, cultures, history, ecology—but to give Terramythica true “framework” strength, consider weaving in these additional structural pillars:

1. Magic & Science Mechanics
Foundational Laws: Define a clear set of rules or “axioms” for how magic and techno‑arcana operate. What governs Emblem potency, leyline flow, mana conservation or the limits of magitech?

Costs & Consequences: Every power needs a price (physical fatigue, emotional burnout, ecological backlash). Consistent costs reinforce stakes and prevent “magic solves everything.”

Discovery & Research: Who studies these laws? What institutions or rival schools debate theory vs. praxis? Think universities, secret cabals, and forbidden libraries.

2. Religion, Myth & Cosmology
Pantheon or Spirit Ecology: Are there gods, demi‑divine ancestors, or spirit‑hosts tied to natural forces or leylines? How do Empathari myths differ from Emberward animism?

Creation Myths & Prophecies: Core origin stories and major prophecies (e.g., the return of the Undreamt King) give cultures shared anchor points—and narrative hooks.

Ritual Calendar: Festivals, holy seasons, pilgrimages and fasts—not just ceremony, but social glue and political flashpoints.

3. Language & Script
Tongues & Dialects: A few sample words, naming conventions, or proverbs for each civilization deepen cultural texture. Perhaps the Empathari speak in tonal “heart‑language,” while Caedharon uses a runic script etched in iron.

Written Traditions: Who records history? Scribes of Aethergrammata vs. oral Flamekeeper lore. Do some scripts “sing” when touched?

4. Politics, Law & Economy
Power Structures: Beyond government type, flesh out key offices, election or accession processes, and how Emblematic status alters one’s civil rights or duties.

Legal Codes & Justice: What laws govern emotional crime (e.g., emotion murder, illegal Emblem suppression)? Courts, inquisitions, or dueling codes?

Trade & Currency: What do you trade—ashfire crystals, memory‑spores, emotion‑drives? Are there standard coins (e.g., electrum glyphs) or emotion‑backed credits?

5. Infrastructure & Technology
Transportation Networks: Flying caravans on Skyrays, ley‑train lines through Vael’Thorne, Memory Ferries across the Divide.

Communication: Leystream beacons, empathic message crystallizers, coded chorus‑networks of the Dissonant Choir.

Urban Design & Architecture: How do floating cities anchor? What building materials reflect emotional resonance (e.g., Lumenbark halls)?

6. Social Structures & Daily Life
Class & Caste Dynamics: How do nobles, commoners, craftsmen, and Emblematic coexist or clash?

Education & Apprenticeship: What does a scribe’s education look like vs. an Emberward acolyte or a technomyst engineer?

Customs & Etiquette: Greeting rituals, dating norms, hospitality codes—in fluently imagined details these make cultures feel lived‑in.

7. Calendars & Timekeeping
Year/Naming Conventions: Beyond “FA” and “AE,” consider lunar phases tied to emotional cycles or ley‑flare seasons.

Holidays & Commemorations: Mark events like the Shatterfall or Binding Accord with national holidays (and political protests).

8. Spatial Reference & Cartography
Detailed Maps: Region‑by‑region maps with trade routes, leylines, Hollowed “blight zones,” and hidden ruins.

Navigational Lore: Legends of “lost islands” in the Divide or hidden sky‑bridges that appear once per decade.

9. Language of Emotion
Emotional Taxonomy: A codified glossary of feelings, moods, and their magical equivalents—so you can precisely describe how characters interact with local climaephoria.

Emotion‑Driven Technology: Tools that require a mood­—like the Seraphine Lens that only functions under genuine awe.

10. Toolkit for Writers & Players
Worldbible Structure: A living document with entries, cross‑references, and “expansion slots” for new Emblem types, artifacts, or side‑quests.

Random Tables & Hooks: Encounters, NPC motivations, artifact rumors, and mini‑adventures that keep every session unpredictable.

Next Steps:

Pick one pillar (e.g., Magic Mechanics) and draft its core principles in detail.

Prototype a calendar (list of 12 months tied to emotional seasons).

Sketch a map with major leyline nodes and Hollowed zones.

Let me know which of these you’d like to tackle first—or if another area needs bolstering—and we’ll build it out with the same depth and flair!
